
# Matbakh Al Yawm — Website Repo

This repository includes the static website for Matbakh Al Yawm with:
- Home Page
- About Page
- Campaign Page
- WhatsApp Order Page
- Auto Deployment pipeline (GitHub Actions)
